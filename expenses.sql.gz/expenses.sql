-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 23, 2018 at 09:03 PM
-- Server version: 5.6.35-log
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `expenses`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) UNSIGNED NOT NULL,
  `category_icon` varchar(200) NOT NULL,
  `category_color` varchar(12) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `created_by` int(11) UNSIGNED NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_icon`, `category_color`, `category_name`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'category_icon_food', 'cyan', 'Restaurant', '2018-09-23 16:01:51', 1, '0000-00-00 00:00:00', 0),
(2, 'category_icon_car', 'pink', 'Transportation', '2018-09-23 16:01:51', 1, '0000-00-00 00:00:00', 0),
(3, 'category_icon_apple', 'purple', 'Vegetables & Fruits', '2018-09-23 16:01:51', 1, '0000-00-00 00:00:00', 0),
(4, 'category_icon_entertainment', 'indigo', 'Party', '2018-09-23 16:01:51', 1, '0000-00-00 00:00:00', 0),
(5, 'category_icon_gas', 'teal', 'Fuel', '2018-09-23 16:01:51', 1, '0000-00-00 00:00:00', 0),
(6, 'category_icon_shopping', 'amber', 'Shipping', '2018-09-23 16:01:51', 1, '0000-00-00 00:00:00', 0),
(7, 'category_icon_money', 'orange', 'Salary', '2018-09-23 16:01:51', 1, '0000-00-00 00:00:00', 0),
(8, 'category_icon_coffee', 'brown', 'Extra Income', '2018-09-23 16:01:51', 1, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`version`) VALUES
(3);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) UNSIGNED NOT NULL,
  `uid` int(11) UNSIGNED NOT NULL,
  `transaction_type` enum('expense','income') NOT NULL,
  `category_id` int(11) UNSIGNED NOT NULL,
  `amount` float NOT NULL,
  `notes` text NOT NULL,
  `created_at` datetime NOT NULL,
  `transaction_date` date NOT NULL,
  `created_by` int(11) UNSIGNED NOT NULL,
  `updated_at` datetime NOT NULL,
  `updated_by` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `uid`, `transaction_type`, `category_id`, `amount`, `notes`, `created_at`, `transaction_date`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 1, 'expense', 4, 89, 'My Birthday Party!!!', '2018-09-23 20:26:00', '2018-09-12', 1, '0000-00-00 00:00:00', 0),
(2, 1, 'expense', 5, 17, 'For my car', '2018-09-23 06:34:47', '2018-09-10', 1, '0000-00-00 00:00:00', 0),
(4, 1, 'income', 7, 12200, 'Salary for August', '2018-09-23 20:48:37', '2018-09-01', 1, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(60) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'user', 'user@expensestracker.com', 'e10adc3949ba59abbe56e057f20f883e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
